# Minecraft Original Assets — Local Extractor

This package contains **an extractor, not copyrighted Minecraft assets**. Run it on a computer with Minecraft **Java Edition** installed to produce a ZIP of the actual PNG textures and native JSON model/blockstate files from your own installed client JAR.

## Windows (PowerShell)

1. Install and launch Minecraft Java Edition once using the official launcher.
2. Extract this ZIP into a folder.
3. Open PowerShell in that folder.
4. Run:

```powershell
py extract_assets.py --output Minecraft_Original_Visual_Assets.zip
```

To target a particular installed version:

```powershell
py extract_assets.py --version 1.21.4 --output Minecraft_Original_Visual_Assets.zip
```

Or supply the JAR path explicitly:

```powershell
py extract_assets.py --jar "$env:APPDATA\.minecraft\versions\1.21.4\1.21.4.jar"
```

## macOS / Linux

```bash
python3 extract_assets.py --output Minecraft_Original_Visual_Assets.zip
```

## What's in the generated ZIP?

- `assets/minecraft/textures/`: genuine PNG images for blocks, items, entities, etc.
- `assets/minecraft/models/`: genuine native Minecraft model definitions (`.json`)
- `assets/minecraft/blockstates/`: block-to-model mappings (`.json`)
- `assets/minecraft/items/`: newer item display definitions, where present
- `assets/minecraft/atlases/`: texture atlas definitions
- `ASSET_MANIFEST.json`: version and counts

**Important:** Minecraft's native JSON model format is not GLB/OBJ. To get `.glb` files, you need an additional renderer/converter that resolves parent models, textures, UV coordinates, block states, and special-case renderers. Do not rename JSON files to GLB.

If no JAR is detected, use `--jar` to point to your installed Java Edition client JAR. This script does not download game files, bypass authentication, or package a copy of the game.

## Licensing

Minecraft assets belong to their respective rights holders. Use the extracted assets according to the Minecraft EULA and Usage Guidelines. Do not assume you can publicly redistribute the ZIP or host the raw files on a public website.
