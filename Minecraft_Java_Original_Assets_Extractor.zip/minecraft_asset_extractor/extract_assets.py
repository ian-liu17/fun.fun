#!/usr/bin/env python3
"""Extract Minecraft Java Edition visual assets from a locally installed client JAR."""
import argparse, json, os, sys, zipfile
from pathlib import Path
from collections import Counter

ROOTS = [Path(os.environ.get('APPDATA',''))/'.minecraft' if os.environ.get('APPDATA') else None,
         Path.home()/'.minecraft', Path.home()/'Library/Application Support/minecraft']
ROOTS = [p for p in ROOTS if p]
PREFIXES = ('assets/minecraft/textures/', 'assets/minecraft/models/', 'assets/minecraft/blockstates/', 'assets/minecraft/items/', 'assets/minecraft/atlases/')

def versions(root):
    d=root/'versions'
    if not d.is_dir(): return []
    return sorted([p for p in d.glob('*/*.jar') if p.is_file()], key=lambda p:p.stat().st_mtime, reverse=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jar',type=Path,help='Path to Minecraft Java version JAR')
    parser.add_argument('--minecraft-dir',type=Path,help='Minecraft directory containing versions/')
    parser.add_argument('--output',type=Path,default=Path('Minecraft_Original_Visual_Assets.zip'))
    parser.add_argument('--version',help='Version folder name, e.g. 1.21.4')
    args=parser.parse_args()
    jar=args.jar
    if jar is None:
        roots=[args.minecraft_dir] if args.minecraft_dir else ROOTS
        found=[]
        for root in roots:
            if not root: continue
            found += versions(root)
        if args.version:
            found=[p for p in found if p.parent.name==args.version]
        if not found:
            print('No local Minecraft Java client JAR found. Launch Java Edition once, then retry, or specify --jar.',file=sys.stderr)
            return 2
        jar=found[0]
    if not jar.is_file():
        print(f'Not found: {jar}',file=sys.stderr); return 2
    counts=Counter()
    with zipfile.ZipFile(jar,'r') as source, zipfile.ZipFile(args.output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as target:
        names=set()
        for info in source.infolist():
            name=info.filename
            if info.is_dir() or not name.startswith(PREFIXES) or name in names: continue
            if '..' in Path(name).parts: continue
            names.add(name)
            target.writestr(name,source.read(info))
            counts[name.split('/')[2]]+=1
        manifest={'source':'User-owned locally installed Minecraft Java Edition client JAR', 'source_jar':jar.name,
                  'version_folder':jar.parent.name,'file_counts':dict(counts),
                  'notes':['Model JSON files are native Minecraft block/item model definitions, not GLB/OBJ meshes.',
                           'Some blocks/entities use procedural or code-driven rendering and cannot be represented by a single JSON model.',
                           'Keep assets for personal use; follow Minecraft EULA and usage guidelines before redistribution.']}
        target.writestr('ASSET_MANIFEST.json',json.dumps(manifest,indent=2))
    print('Created:',args.output.resolve())
    print('Source:',jar)
    for category,count in sorted(counts.items()):print(f'  {category}: {count}')
    print('Note: This archive contains actual PNG textures and Minecraft JSON models, not pre-rendered GLB files.')
    return 0
if __name__=='__main__':raise SystemExit(main())
